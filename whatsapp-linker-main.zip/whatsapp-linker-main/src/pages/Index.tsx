import { useState } from "react";
import { Play, Tv, Smartphone, Monitor, Tablet, Laptop, Zap, Shield, Clock, RefreshCw, Headphones, Star, ChevronDown, ChevronUp, MessageCircle } from "lucide-react";
import logo from "@/assets/logo.png";

const WHATSAPP_NUMBER = "5511999999999";

const getWhatsAppLink = (message: string) => {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
};

const Index = () => {
  const [activePlan, setActivePlan] = useState<string | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const handlePlanClick = (plan: string, price: string) => {
    setActivePlan(plan);
    const message = `Olá! Tenho interesse no plano ${plan} - ${price}. Gostaria de mais informações.`;
    window.open(getWhatsAppLink(message), "_blank");
  };

  const handleTesteGratis = () => {
    const message = "Olá! Gostaria de solicitar um teste grátis do UPTV.";
    window.open(getWhatsAppLink(message), "_blank");
  };

  const handleVerPlanos = () => {
    document.getElementById("planos")?.scrollIntoView({ behavior: "smooth" });
  };

  const faqs = [
    {
      question: "Precisa de internet rápida?",
      answer: "Recomendamos uma conexão de pelo menos 10 Mbps para conteúdos em Full HD e 25 Mbps para 4K. A maioria das conexões residenciais atuais atende perfeitamente."
    },
    {
      question: "Posso testar antes de pagar?",
      answer: "Sim! Oferecemos teste grátis para você conhecer nossa qualidade antes de assinar qualquer plano."
    },
    {
      question: "Funciona em qualquer TV?",
      answer: "Funciona em Smart TVs (Android TV, Tizen, WebOS), TV Box, celulares, tablets e computadores."
    },
    {
      question: "Quantos dispositivos posso usar?",
      answer: "Depende do plano escolhido: Mensal (1 dispositivo), Trimestral (2 dispositivos) ou Semestral (3 dispositivos)."
    },
    {
      question: "Tem suporte técnico?",
      answer: "Sim! Oferecemos suporte 24 horas via WhatsApp para ajudar com qualquer dúvida ou problema."
    },
    {
      question: "Como é feito o pagamento?",
      answer: "Aceitamos PIX, cartão de crédito e boleto bancário. O pagamento é seguro e rápido."
    },
    {
      question: "Posso cancelar a qualquer momento?",
      answer: "Sim, você pode cancelar quando quiser. Não há fidelidade ou multa por cancelamento."
    }
  ];

  const testimonials = [
    { name: "Carlos M.", location: "São Paulo, SP", text: "Imagem perfeita! Assisto todos os jogos do meu time em Full HD sem nenhum travamento.", initial: "C" },
    { name: "Ana Paula S.", location: "Rio de Janeiro, RJ", text: "Sem travamentos nunca! Já testei outros serviços e nenhum chega perto da qualidade do UPTV.", initial: "A" },
    { name: "Roberto L.", location: "Belo Horizonte, MG", text: "Suporte excelente e rápido! Tive uma dúvida às 23h e fui atendido em menos de 5 minutos.", initial: "R" },
    { name: "Fernanda O.", location: "Curitiba, PR", text: "Melhor custo-benefício que já encontrei. Qualidade de cinema na minha sala!", initial: "F" },
    { name: "Marcos V.", location: "Salvador, BA", text: "Instalação super fácil. Em 10 minutos já estava assistindo meus canais favoritos.", initial: "M" },
    { name: "Juliana R.", location: "Porto Alegre, RS", text: "Funciona perfeitamente na minha Smart TV e no celular. Recomendo demais!", initial: "J" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <img src={logo} alt="UPTV Revenda" className="h-10" />
          <nav className="hidden md:flex items-center gap-8">
            <a href="#planos" className="text-muted-foreground hover:text-foreground transition-colors">Planos</a>
            <a href="#como-funciona" className="text-muted-foreground hover:text-foreground transition-colors">Como Funciona</a>
            <a href="#faq" className="text-muted-foreground hover:text-foreground transition-colors">FAQ</a>
          </nav>
          <button
            onClick={handleTesteGratis}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-5 py-2.5 rounded-lg font-semibold transition-all"
          >
            TESTE GRÁTIS
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-secondary px-4 py-2 rounded-full mb-8">
            <Play className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Streaming Premium</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Entretenimento <span className="text-metallic">sem limites</span>
            <br />na palma da sua mão
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
            Assista canais ao vivo, filmes e séries em <strong className="text-foreground">Full HD, 2K e 4K</strong> com máxima estabilidade em qualquer dispositivo.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={handleTesteGratis}
              className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-xl font-semibold transition-all"
            >
              <Play className="w-5 h-5" />
              TESTE GRÁTIS NO WHATSAPP
            </button>
            <button
              onClick={handleVerPlanos}
              className="px-8 py-4 rounded-xl font-semibold border border-border hover:bg-secondary transition-all text-foreground"
            >
              VER PLANOS
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto">
            <div className="stat-item">
              <div className="stat-value text-metallic">10K+</div>
              <div className="stat-label">Canais</div>
            </div>
            <div className="stat-item border-l border-border">
              <div className="stat-value text-metallic">4K</div>
              <div className="stat-label">Qualidade</div>
            </div>
            <div className="stat-item border-l border-border">
              <div className="stat-value text-metallic">24/7</div>
              <div className="stat-label">Suporte</div>
            </div>
            <div className="stat-item border-l border-border">
              <div className="stat-value text-metallic">99.9%</div>
              <div className="stat-label">Uptime</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Por que escolher o <span className="text-metallic">UPTV</span>?
          </h2>
          <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
            Tecnologia de ponta para sua melhor experiência de entretenimento
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Monitor, title: "Full HD, 2K e 4K", desc: "Imagem cristalina em todas as resoluções disponíveis" },
              { icon: Shield, title: "Servidores Estáveis", desc: "Sem travamentos, streaming fluido 24 horas" },
              { icon: Tv, title: "Milhares de Conteúdos", desc: "Canais ao vivo, filmes, séries e muito mais" },
              { icon: Smartphone, title: "Multi-dispositivos", desc: "Smart TV, Android TV, TV Box, celular e PC" },
              { icon: RefreshCw, title: "Atualizações Diárias", desc: "Novos conteúdos adicionados todos os dias" },
              { icon: Headphones, title: "Suporte 24 Horas", desc: "Atendimento rápido via WhatsApp" }
            ].map((feature, index) => (
              <div key={index} className="feature-card">
                <feature.icon className="w-10 h-10 text-primary mb-4" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="como-funciona" className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Como funciona?
          </h2>
          <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
            Em poucos minutos você estará assistindo seus conteúdos favoritos
          </p>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Solicite o Teste", desc: "Entre em contato pelo WhatsApp e solicite seu teste grátis" },
              { step: "02", title: "Instale o App", desc: "Baixe e instale o aplicativo recomendado no seu dispositivo" },
              { step: "03", title: "Receba o Acesso", desc: "Receba seu login exclusivo ou lista M3U por WhatsApp" },
              { step: "04", title: "Comece a Assistir", desc: "Pronto! Aproveite milhares de canais e conteúdos" }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-5xl font-bold text-primary/30 mb-4">{item.step}</div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="planos" className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Escolha seu plano
          </h2>
          <p className="text-muted-foreground text-center mb-12">
            Preços acessíveis para o melhor entretenimento
          </p>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {/* Mensal */}
            <div 
              className={`plan-card ${activePlan === "Mensal" ? "active" : ""}`}
              onClick={() => handlePlanClick("Mensal", "R$29,90/mês")}
            >
              <h3 className="text-xl font-semibold mb-2">Mensal</h3>
              <p className="text-muted-foreground text-sm mb-4">Ideal para conhecer o serviço</p>
              <div className="mb-6">
                <span className="text-4xl font-bold">R$29,90</span>
                <span className="text-muted-foreground">/ mês</span>
              </div>
              <ul className="space-y-3 mb-6">
                {["Acesso a todos os canais", "Filmes e séries ilimitados", "Qualidade até 4K", "Suporte 24h", "1 dispositivo"].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm">
                    <Zap className="w-4 h-4 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
              <button className="plan-button">
                Assinar Agora
              </button>
            </div>

            {/* Trimestral */}
            <div 
              className={`plan-card ${activePlan === "Trimestral" ? "active" : ""}`}
              onClick={() => handlePlanClick("Trimestral", "R$79,90/3 meses")}
            >
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-xs font-semibold">
                Mais Popular
              </div>
              <h3 className="text-xl font-semibold mb-2">Trimestral</h3>
              <p className="text-muted-foreground text-sm mb-4">Mais economia para você</p>
              <div className="mb-6">
                <span className="text-muted-foreground line-through text-sm mr-2">R$ 89,70</span>
                <br />
                <span className="text-4xl font-bold">R$79,90</span>
                <span className="text-muted-foreground">/ 3 meses</span>
              </div>
              <ul className="space-y-3 mb-6">
                {["Acesso a todos os canais", "Filmes e séries ilimitados", "Qualidade até 4K", "Suporte 24h prioritário", "2 dispositivos"].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm">
                    <Zap className="w-4 h-4 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
              <button className="plan-button">
                Assinar Agora
              </button>
            </div>

            {/* Semestral */}
            <div 
              className={`plan-card ${activePlan === "Semestral" ? "active" : ""}`}
              onClick={() => handlePlanClick("Semestral", "R$149,90/6 meses")}
            >
              <h3 className="text-xl font-semibold mb-2">Semestral</h3>
              <p className="text-muted-foreground text-sm mb-4">Melhor custo-benefício</p>
              <div className="mb-6">
                <span className="text-muted-foreground line-through text-sm mr-2">R$ 179,40</span>
                <br />
                <span className="text-4xl font-bold">R$149,90</span>
                <span className="text-muted-foreground">/ 6 meses</span>
              </div>
              <ul className="space-y-3 mb-6">
                {["Acesso a todos os canais", "Filmes e séries ilimitados", "Qualidade até 4K", "Suporte 24h VIP", "3 dispositivos"].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm">
                    <Zap className="w-4 h-4 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
              <button className="plan-button">
                Assinar Agora
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Devices */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Compatível com seus dispositivos
          </h2>
          <p className="text-muted-foreground text-center mb-12">
            Assista onde e quando quiser, em qualquer tela
          </p>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 max-w-4xl mx-auto mb-8">
            {[
              { icon: Tv, name: "Smart TV", desc: "Android TV, Tizen, WebOS" },
              { icon: Monitor, name: "TV Box", desc: "Todos os modelos" },
              { icon: Smartphone, name: "Celular", desc: "Android e iOS" },
              { icon: Tablet, name: "Tablet", desc: "Todos os tamanhos" },
              { icon: Laptop, name: "Computador", desc: "Windows, Mac, Linux" }
            ].map((device, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 bg-secondary rounded-2xl flex items-center justify-center">
                  <device.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-1">{device.name}</h3>
                <p className="text-muted-foreground text-xs">{device.desc}</p>
              </div>
            ))}
          </div>

          <p className="text-center text-muted-foreground text-sm max-w-2xl mx-auto">
            Compatível com Smart TVs (Android TV, Tizen, WebOS), TV Box, celulares Android/iOS, tablets, notebooks e computadores. Instale o app e comece a assistir em minutos!
          </p>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            O que nossos clientes dizem
          </h2>
          <p className="text-muted-foreground text-center mb-12">
            Milhares de clientes satisfeitos em todo o Brasil
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-background border border-border rounded-2xl p-6">
                <p className="text-muted-foreground mb-4 text-sm">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-semibold">
                    {testimonial.initial}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{testimonial.name}</div>
                    <div className="text-muted-foreground text-xs">{testimonial.location}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 px-4">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Perguntas Frequentes
          </h2>
          <p className="text-muted-foreground text-center mb-12">
            Tire suas dúvidas sobre nosso serviço
          </p>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-border rounded-xl overflow-hidden">
                <button
                  className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-secondary/50 transition-colors"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <span className="font-semibold">{faq.question}</span>
                  {openFaq === index ? (
                    <ChevronUp className="w-5 h-5 text-primary" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-4 text-muted-foreground text-sm">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-full mb-6">
            <Star className="w-4 h-4" />
            <span className="text-sm font-semibold">Teste Grátis Disponível</span>
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Comece agora com seu teste grátis
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Não perca mais tempo! Entre em contato agora e descubra a melhor experiência de entretenimento digital.
          </p>
          
          <button
            onClick={handleTesteGratis}
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-xl font-semibold transition-all"
          >
            <MessageCircle className="w-5 h-5" />
            Falar no WhatsApp
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          © 2024 UPTV Revenda. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  );
};

export default Index;
